using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace server
{
    public partial class serverFirst : DbContext
    {
        public serverFirst()
            : base("name=serverFirst")
        {
        }

        public virtual DbSet<UsersList> UsersList { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UsersList>()
                .Property(e => e.ClientName)
                .IsFixedLength();

            modelBuilder.Entity<UsersList>()
                .Property(e => e.Password)
                .IsFixedLength();
        }
    }
}
