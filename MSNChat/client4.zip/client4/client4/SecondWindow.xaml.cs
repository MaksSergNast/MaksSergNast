﻿using System;
using System.Data.Common;
using System.Data;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Controls;
using System.IO;
using System.Xml.Linq;

namespace client4
{
    public partial class SecondWindow : Window
    {
        
        bool _isWindowPrivate = false;
        
        private TcpClient _client;
        private NetworkStream _stream;
        private Thread _thread;
        private string _name; // добавляем поле для имени пользователя

        SqlConnection conn = null;
        DataAdapter adapter = null;
        DataSet ds = null;
        string sSendingText;

        public SecondWindow(TcpClient client, NetworkStream stream, string name, bool isWindowPrivate) // добавляем параметр для имени пользователя 
        {
            InitializeComponent();
            _client = client;
            _stream = stream;
            _name = name; // сохраняем имя пользователя
            _isWindowPrivate = isWindowPrivate;

            if (_isWindowPrivate)
            {
                Users_DG.Visibility = Visibility.Hidden;
                Title = "Приватный чат с " + name;
            }
            else {
                
                Users_DG.Visibility = Visibility.Visible;
                Title = "Общий чат ("+ _name+")";

            }

            

            // отправляем имя на сервер
            byte[] nameBytes = Encoding.UTF8.GetBytes(_name);
            _stream.Write(nameBytes, 0, nameBytes.Length);

            // Запускаем новый поток для чтения входящих сообщений
            _thread = new Thread(new ThreadStart(ReadMessages));
            _thread.Start();


            conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["HW2CS"].ConnectionString.ToString();

            SqlCommand cmd = new SqlCommand("select NickName as [Список пользователей] from UsersList", conn);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);

            DataTable tmpDataTable = new DataTable();
            adapter.Fill(tmpDataTable);
            Users_DG.ItemsSource = tmpDataTable.DefaultView;
            _isWindowPrivate = isWindowPrivate;
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, пустое ли поле ввода или содержит ли оно команду "exit"
            if (string.IsNullOrEmpty(ChatInput.Text) || ChatInput.Text.ToLower() == "exit")
            {
                // Закрываем соединение
                _client.Close();
                _thread.Join(); // Ждем завершения потока чтения сообщений
                this.Close(); // Закрываем окно
                return;
            }


            sSendingText = ChatInput.Text;
            if (_isWindowPrivate) { sSendingText = "private_" + _name + " ЛС от "+ _name; }

            // Добавляем введенный текст в поле вывода чата
            ChatOutput.Text += ChatInput.Text + Environment.NewLine;

            
            // Отправляем сообщение на сервер
            SendMessage(ChatInput.Text);

            // Очищаем поле ввода
            ChatInput.Clear();
        }

        // метод чтения сообщений
        public void ReadMessages()
        {
            while (_client.Connected)
            {
                byte[] data = new byte[256];

                if (data.Length != 0)
                {
                    int bytes = _stream.Read(data, 0, data.Length);
                    string responseData = Encoding.UTF8.GetString(data, 0, bytes);

                    // Обновляем поле вывода чата в главном потоке
                    Dispatcher.Invoke(() =>
                    {
                        ChatOutput.Text += responseData + Environment.NewLine;
                    });
                }
            }
        }

        //метод рассылки сообщений
        public void SendMessage(string message)
        {
            if (_stream.CanWrite)
            {
                byte[] clientMessageAsByteArray = Encoding.UTF8.GetBytes(message);
                _stream.Write(clientMessageAsByteArray, 0, clientMessageAsByteArray.Length);
            }
        }

        // Закрываем соединение при закрытии окна
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            
            _client.Close();
            _client.Dispose();
            _thread.Join(); // Ждем завершения потока чтения сообщений
            _stream.Close();

        }

        private void Users_DG_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            _isWindowPrivate = true;
            string _name = ((DataRowView)Users_DG.SelectedItems[0]).Row["Список пользователей"].ToString();
            //MessageBox.Show(_name);

            SecondWindow privateWindow = new SecondWindow(_client, _stream, _name, _isWindowPrivate);
            privateWindow.Show();
        }
    }
}
